function test(){
	
	console.log("inside state.js")
}