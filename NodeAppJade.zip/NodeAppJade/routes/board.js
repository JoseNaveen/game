/**
 * http://usejsdoc.org/
 */
exports.board = function(req, res){
  res.render('index', { title: 'Express' });
};